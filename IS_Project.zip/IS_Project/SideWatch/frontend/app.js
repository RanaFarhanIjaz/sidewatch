const statusText = document.querySelector("#service-status");
const statusDot = document.querySelector("#status-dot");
const engineVersion = document.querySelector("#engine-version");
const fixtureList = document.querySelector("#fixture-list");
const refreshButton = document.querySelector("#refresh-button");

function showMessage(message) {
  const item = document.createElement("li");
  item.className = "fixture-card fixture-message";
  item.textContent = message;
  fixtureList.replaceChildren(item);
}

function renderFixtures(fixtures) {
  if (!Array.isArray(fixtures) || fixtures.length === 0) {
    showMessage("No fixtures are currently available.");
    return;
  }

  const cards = fixtures.map((fixture) => {
    const item = document.createElement("li");
    item.className = "fixture-card";

    const title = document.createElement("h3");
    title.textContent = fixture.id;
    const description = document.createElement("p");
    description.textContent = fixture.description;
    const metadata = document.createElement("span");
    metadata.className = "fixture-meta";
    metadata.textContent = fixture.jitter_stddev_ns > 0
      ? `${fixture.matching_prefix_bytes} matching byte(s) · ${fixture.jitter_stddev_ns} ns simulated jitter`
      : `${fixture.matching_prefix_bytes} matching byte(s) · no simulated jitter`;

    item.append(title, description, metadata);
    return item;
  });

  fixtureList.replaceChildren(...cards);
}

async function loadDashboard() {
  refreshButton.disabled = true;
  statusText.textContent = "Checking service…";
  statusDot.classList.remove("is-online", "is-offline");

  try {
    const response = await fetch("/api/dashboard", {
      cache: "no-store",
      credentials: "omit",
      headers: { Accept: "application/json" },
    });
    if (!response.ok) {
      throw new Error(`Dashboard request failed (${response.status}).`);
    }

    const dashboard = await response.json();
    if (dashboard.status !== "ok" || typeof dashboard.engine_version !== "string") {
      throw new Error("Dashboard response was invalid.");
    }

    statusText.textContent = "Online";
    statusDot.classList.add("is-online");
    engineVersion.textContent = `Engine v${dashboard.engine_version}`;
    renderFixtures(dashboard.fixtures);
  } catch {
    statusText.textContent = "Unavailable";
    statusDot.classList.add("is-offline");
    engineVersion.textContent = "";
    showMessage("Could not load service information. Check that the backend is running and try again.");
  } finally {
    refreshButton.disabled = false;
  }
}

refreshButton.addEventListener("click", loadDashboard);
loadDashboard();
