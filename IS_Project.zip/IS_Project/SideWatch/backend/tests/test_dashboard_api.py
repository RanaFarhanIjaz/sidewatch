from fastapi.testclient import TestClient

from backend.app.main import app
from engine.interface import ENGINE_VERSION


def test_dashboard_is_public_and_returns_safe_fixture_metadata():
    response = TestClient(app).get("/api/dashboard")

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["engine_version"] == ENGINE_VERSION
    assert {fixture["id"] for fixture in body["fixtures"]} == {
        "no_match",
        "prefix_1",
        "prefix_4",
        "full_match",
        "prefix_1_jitter",
        "prefix_4_jitter",
    }
    assert all(
        {"id", "description", "matching_prefix_bytes", "jitter_stddev_ns"}
        == set(fixture)
        for fixture in body["fixtures"]
    )


def test_dashboard_uses_api_security_headers():
    response = TestClient(app).get("/api/dashboard")

    assert response.headers["content-security-policy"] == (
        "default-src 'none'; frame-ancestors 'none'"
    )
