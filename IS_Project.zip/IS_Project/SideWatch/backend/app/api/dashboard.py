from fastapi import APIRouter

from engine.fixtures import FIXTURES
from engine.interface import ENGINE_VERSION

router = APIRouter(prefix="/api", tags=["dashboard"])


@router.get("/dashboard")
def get_dashboard():
    """Public, read-only status and fixture metadata for the landing page."""
    return {
        "status": "ok",
        "engine_version": ENGINE_VERSION,
        "fixtures": [
            {
                "id": fixture_id,
                "description": fixture.description,
                "matching_prefix_bytes": fixture.matching_prefix_bytes,
                "jitter_stddev_ns": fixture.jitter_stddev_ns,
            }
            for fixture_id, fixture in FIXTURES.items()
        ],
    }
